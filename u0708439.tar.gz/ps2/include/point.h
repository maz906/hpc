#pragma once

typedef struct _Point {
	double x;
	double y;
} Point;

typedef struct _Vector {
	double x;
	double y;
	double z;
} Vector;
