#!/bin/bash

./bin/main_test $1 $2 $3
