#!/bin/bash

./bin/main_time $1 $2 $3
