#pragma once
#include "stddef.h"

void scan_test(int size);
void basic_scan_test(int size, int increment);
void rigor_scan_test(int size);
