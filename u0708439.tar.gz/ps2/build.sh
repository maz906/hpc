#!/bin/bash

mkdir cmake
cd cmake
cmake ..
make all
cd ..
